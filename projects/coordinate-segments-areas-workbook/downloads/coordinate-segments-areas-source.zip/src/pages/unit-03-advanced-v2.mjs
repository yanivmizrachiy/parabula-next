// יחידה 3 — שטחי משולשים מתקדמים, גרסה נקייה ומבודדת (עמודים 39–45).
// קובץ זה מחליף בבנייה את unit-03-advanced.mjs שנפגע מכתיבות מקבילות.

import { createGrid } from '../coordinate-svg.mjs';
import {
  task, subs, choices, note, lines, expr, exprPoint,
  table, figure, cols, pt, ltr
} from '../render.mjs';

const UNIT = 'יחידה 3 — שטחי משולשים במערכת הצירים';
const SHORT = '<span class="wline wline-short"></span>';

function grid(opts) {
  return createGrid(opts).grid().axes();
}

function point(g, label, x, y, dx = 5, dy = -6) {
  g.point(x, y, label, { dx, dy });
}

function diagram39() {
  const g = grid({ xMin: -1, xMax: 11, yMin: -1, yMax: 9, unit: 15 });
  g.polygon([[1, 1], [9, 1], [9, 7], [1, 7]]);
  g.segment([1, 1], [9, 7], { dashed: true });
  point(g, 'A', 1, 1, -5, 10); point(g, 'B', 9, 1, 5, 10);
  point(g, 'C', 9, 7, 5, -6); point(g, 'D', 1, 7, -5, -6);
  point(g, 'P', 3, 7, 0, -7); point(g, 'Q', 6, 7, 0, -7);
  return g;
}

function diagram40() {
  const g = grid({ xMin: -1, xMax: 11, yMin: -1, yMax: 9, unit: 15 });
  g.polygon([[0, 0], [10, 0], [10, 8], [0, 8]]);
  g.polygon([[0, 0], [10, 0], [4, 8]], { cls: 'cg-poly cg-highlight' });
  point(g, 'A', 0, 0, -5, 11); point(g, 'B', 10, 0, 5, 11); point(g, 'C', 4, 8, 0, -7);
  return g;
}

function diagram41() {
  const g = grid({ xMin: -2, xMax: 10, yMin: -2, yMax: 8, unit: 16 });
  g.polygon([[0, 0], [8, 0], [0, 6]]);
  point(g, 'O', 0, 0, -7, 11); point(g, 'A', 8, 0, 5, 11); point(g, 'B', 0, 6, -7, -6);
  point(g, 'P', 2, 2, 5, -5); point(g, 'Q', 4, 3, 5, -5); point(g, 'R', 6, 3, 5, -5);
  return g;
}

function diagram42() {
  const g = grid({ xMin: -2, xMax: 12, yMin: -4, yMax: 10, unit: 12 });
  g.segment([2, 3], [10, 3]);
  g.segment([-2, 8], [12, 8], { dashed: true });
  g.segment([-2, -2], [12, -2], { dashed: true });
  point(g, 'A', 2, 3, -5, 11); point(g, 'B', 10, 3, 5, 11);
  point(g, 'C₁', 5, 8, 5, -6); point(g, 'C₂', 7, -2, 5, 11);
  return g;
}

function diagram43() {
  const g = grid({ xMin: -1, xMax: 13, yMin: -1, yMax: 10, unit: 13 });
  g.segment([1, 2], [9, 2]);
  g.segment([-1, 8], [13, 8], { dashed: true });
  point(g, 'A', 1, 2, -5, 11); point(g, 'B', 9, 2, 5, 11);
  point(g, 'P', 2, 8, 0, -7); point(g, 'Q', 5, 8, 0, -7); point(g, 'R', 11, 8, 0, -7);
  g.segment([1, 2], [2, 8], { dashed: true });
  g.segment([9, 2], [2, 8], { dashed: true });
  return g;
}

function diagram44() {
  const g = grid({ xMin: -1, xMax: 11, yMin: -1, yMax: 9, unit: 15 });
  g.polygon([[1, 1], [9, 1], [4, 7]]);
  g.segment([4, 7], [5, 1], { dashed: true });
  point(g, 'A', 1, 1, -5, 11); point(g, 'B', 9, 1, 5, 11);
  point(g, 'C', 4, 7, 0, -7); point(g, 'M', 5, 1, 0, 12);
  return g;
}

function diagram45() {
  const g = grid({ xMin: -1, xMax: 12, yMin: -1, yMax: 9, unit: 14 });
  g.polygon([[1, 1], [10, 1], [3, 7]]);
  g.segment([3, 7], [4, 1], { dashed: true });
  point(g, 'A', 1, 1, -5, 11); point(g, 'B', 10, 1, 5, 11);
  point(g, 'C', 3, 7, 0, -7); point(g, 'D', 4, 1, 0, 12);
  return g;
}

const page39 = {
  n: 39, unit: UNIT, title: 'משולש בתוך מלבן — אותו בסיס ואותו גובה',
  blocks: [
    cols(
      task(`במלבן ${pt('A', 1, 1)}, ${pt('B', 9, 1)}, ${pt('C', 9, 7)}, ${pt('D', 1, 7)} שורטט האלכסון AC:`,
        expr(['_', '×', '_', '=', '_'], { label: 'שטח המלבן:' }),
        expr(['_', '÷', '2', '=', '_'], { label: 'שטח כל משולש:' }),
        subs([`האם המשולשים ABC ו־ACD חופפים? ${SHORT}`, `האם שטחיהם שווים? ${SHORT}`]),
        lines(2, { label: 'הסבירו בלי להשתמש שוב בנוסחה:' })
      ),
      figure(diagram39(), 'אלכסון ונקודות על ישר מקביל לבסיס')
    ),
    task('הנקודות P ו־Q נמצאות על הצלע DC. השוו בין שטחי ABP ו־ABQ:',
      table(['המשולש', 'אורך הבסיס AB', 'הגובה אל AB', 'השטח'], [[ltr('ABP')], [ltr('ABQ')]]),
      lines(2, { label: 'איזה נתון השתנה ואיזה נתון נשמר?' })
    ),
    task('השלימו כלל:',
      lines(2, { label: 'משולשים בעלי אותו בסיס וקודקוד שלישי על ישר המקביל לבסיס...' }),
      choices(['שווי שטח', 'חופפים תמיד', 'שווי היקף תמיד'])
    )
  ]
};

const page40 = {
  n: 40, unit: UNIT, title: 'שטח משולש באמצעות חיסור שטחים',
  blocks: [
    cols(
      task(`המשולש ABC נמצא בתוך מלבן שמידותיו ${ltr('10×8')}:`,
        expr(['10', '×', '8', '=', '_'], { label: 'שטח המלבן:' }),
        expr(['4', '×', '8', '÷', '2', '=', '_'], { label: 'שטח המשולש השמאלי החיצוני:' }),
        expr(['6', '×', '8', '÷', '2', '=', '_'], { label: 'שטח המשולש הימני החיצוני:' }),
        expr(['_', '−', '(', '_', '+', '_', ')', '=', '_'], { label: 'שטח ABC בחיסור:' })
      ),
      figure(diagram40(), 'השלמה למלבן וחיסור')
    ),
    task('פתרו את אותו משולש בדרך הישירה:',
      expr(['_', '×', '_', '÷', '2', '=', '_'], { label: 'בסיס × גובה ÷ 2:' }),
      lines(2, { label: 'מדוע שתי הדרכים חייבות לתת אותה תוצאה?' })
    ),
    task('מי צודק?',
      subs([
        'דנה: „צריך לחסר רק את המשולש השמאלי.”',
        'נועם: „צריך לחסר את שני האזורים החיצוניים.”',
        'יובל: „אפשר לחשב ישירות בלי המלבן.”'
      ]),
      lines(3, { label: 'כתבו מה נכון בכל הצעה ומה דורש תיקון:' })
    )
  ]
};

const page41 = {
  n: 41, unit: UNIT, title: 'נקודה בתוך, על או מחוץ למשולש',
  blocks: [
    cols(
      task('מיינו את הנקודות P, Q ו־R:',
        table(['הנקודה', 'בתוך / על / מחוץ', 'נימוק מן השרטוט או מן השטחים'], [[ltr('P')], [ltr('Q')], [ltr('R')]]),
        lines(2, { label: 'איזו נקודה נמצאת בתוך המלבן החוסם אך מחוץ למשולש?' })
      ),
      figure(diagram41(), 'שלוש נקודות ביחס למשולש')
    ),
    task('בדיקת שטחים עבור הנקודה Q:',
      expr(['שטח OAQ', '+', 'שטח OQB', '+', 'שטח AQB', '=', '_'], { label: 'סכום שלושת השטחים:' }),
      expr(['8', '×', '6', '÷', '2', '=', '_'], { label: 'שטח OAB:' }),
      lines(2, { label: 'מה מוכיח השוויון בין הסכומים?' })
    ),
    task('כתבו נקודה נוספת בכל קטגוריה:',
      exprPoint('נקודה בתוך:'),
      exprPoint('נקודה על אחת הצלעות:'),
      exprPoint('נקודה מחוץ למשולש אך בתוך המלבן החוסם:')
    )
  ]
};

const page42 = {
  n: 42, unit: UNIT, title: 'קודקוד חסר לפי שטח נתון',
  blocks: [
    cols(
      task(`נתונות ${pt('A', 2, 3)}, ${pt('B', 10, 3)}. שטח ABC הוא ${ltr('20')}:`,
        expr(['_', '−', '_', '=', '_'], { label: 'אורך AB:' }),
        expr(['8', '×', 'גובה', '÷', '2', '=', '20'], { label: 'משוואת השטח:' }),
        expr(['גובה', '=', '_'], { label: 'הגובה הדרוש:' }),
        subs([`שיעור Y אפשרי מעל AB: ${SHORT}`, `שיעור Y אפשרי מתחת ל־AB: ${SHORT}`])
      ),
      figure(diagram42(), 'שני ישרים אפשריים לקודקוד C')
    ),
    task('מה אפשר לומר על שיעור X של C?',
      choices(['חייב להיות 5', 'יכול להיות כל מספר', 'חייב להיות בין 2 ל־10']),
      lines(2, { label: 'נמקו ותנו שתי נקודות C שונות על אותו ישר:' })
    ),
    task('הוסיפו תנאי וקבעו אם התשובה יחידה:',
      table(['התנאי', 'מספר פתרונות', 'דוגמה'], [
        [ltr('C על הישר x=5 וברביע הראשון')],
        [ltr('C על הישר y=8')],
        [ltr('C על ציר Y')],
        [ltr('C מתחת לציר X וברביע הרביעי')]
      ])
    )
  ]
};

const page43 = {
  n: 43, unit: UNIT, title: 'אותו בסיס ואותו גובה — שטחים שווים',
  blocks: [
    cols(
      task(`הבסיס ${ltr('AB')} נמצא על ${ltr('y=2')}; הנקודות P, Q ו־R נמצאות על ${ltr('y=8')}:`,
        expr(['_', '−', '_', '=', '_'], { label: 'אורך AB:' }),
        expr(['_', '−', '_', '=', '_'], { label: 'הגובה המשותף:' }),
        expr(['_', '×', '_', '÷', '2', '=', '_'], { label: 'שטח כל משולש:' }),
        lines(2, { label: 'מדוע שיעור X של הקודקוד השלישי אינו משנה את השטח?' })
      ),
      figure(diagram43(), 'שלושה קודקודים על ישר מקביל לבסיס')
    ),
    task('קבעו נכון או לא נכון:',
      table(['הטענה', 'נכון / לא נכון', 'נימוק או תיקון'], [
        ['המשולשים ABP, ABQ ו־ABR שווי שטח.'],
        ['המשולשים חופפים תמיד.'],
        ['לכל המשולשים אותו גובה אל AB.'],
        ['אם נזיז את R על y=8, השטח יישמר.']
      ])
    ),
    task('בנו נקודה S נוספת כך ששטח ABS יהיה זהה:',
      exprPoint('S ='),
      lines(2, { label: 'בדיקה:' })
    )
  ]
};

const page44 = {
  n: 44, unit: UNIT, title: 'תיכון ושוויון שטחים',
  blocks: [
    note('תיכון במשולש', ['תיכון מחבר קודקוד עם אמצע הצלע שמולו.', 'התיכון אינו חייב להיות מאונך לצלע.']),
    cols(
      task(`במשולש ABC הנקודה ${ltr('M(5,1)')} היא אמצע AB:`,
        expr(['_', '−', '_', '=', '_'], { label: 'AM:' }),
        expr(['_', '−', '_', '=', '_'], { label: 'MB:' }),
        expr(['_', '×', '_', '÷', '2', '=', '_'], { label: 'שטח ACM:' }),
        expr(['_', '×', '_', '÷', '2', '=', '_'], { label: 'שטח BCM:' }),
        lines(2, { label: 'מדוע הגובה של שני המשולשים זהה?' })
      ),
      figure(diagram44(), 'התיכון CM')
    ),
    task('אם שטח ABC הוא 24:',
      subs([`שטח ACM: ${SHORT}`, `שטח BCM: ${SHORT}`]),
      lines(2, { label: 'הסבירו מדוע אין צורך שהתיכון יהיה גובה:' })
    ),
    task('איתור טעות — תלמיד כתב: „כל תיכון מאונך לצלע ולכן השטחים שווים”.',
      lines(3, { label: 'תקנו את ההסבר:' })
    )
  ]
};

const page45 = {
  n: 45, unit: UNIT, title: 'יחס בין בסיסים ליחס בין שטחים',
  blocks: [
    cols(
      task(`על הבסיס AB נמצאת ${pt('D', 4, 1)}:`,
        expr(['_', '−', '_', '=', '_'], { label: 'AD:' }),
        expr(['_', '−', '_', '=', '_'], { label: 'DB:' }),
        expr(['AD', ':', 'DB', '=', '_', ':', '_'], { label: 'יחס הבסיסים:' }),
        expr(['_', '×', '_', '÷', '2', '=', '_'], { label: 'שטח ACD:' }),
        expr(['_', '×', '_', '÷', '2', '=', '_'], { label: 'שטח BCD:' })
      ),
      figure(diagram45(), 'שני משולשים בעלי גובה משותף')
    ),
    task('השלימו את המסקנה:',
      lines(2, { label: 'כאשר לשני משולשים אותו גובה, יחס השטחים שלהם שווה ל...' }),
      choices(['יחס הבסיסים', 'סכום הבסיסים', 'יחס ההיקפים'])
    ),
    task(`שאלה הפוכה — שטחי שני המשולשים הם ${ltr('15')} ו־${ltr('25')}:`,
      expr(['15', ':', '25', '=', '_', ':', '_'], { label: 'יחס השטחים המצומצם:' }),
      expr(['AD', ':', 'DB', '=', '_', ':', '_'], { label: 'יחס חלקי הבסיס:' }),
      lines(2, { label: 'אם AB=16, מצאו את AD ואת DB:' })
    ),
    task('כתבו דוגמה משלכם במערכת הצירים ליחס שטחים 1:3:',
      table(['נקודה', 'X', 'Y'], [['A'], ['D'], ['B'], ['C']]),
      lines(1, { label: 'בדיקת היחס:' })
    )
  ]
};

export default [page39, page40, page41, page42, page43, page44, page45];
